#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
using namespace Rcpp;
using namespace arma;

// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
arma::colvec STc(arma::colvec z,  double t) {
  NumericVector zc = as<NumericVector>(wrap(z));
  return  as<arma::colvec>(wrap(pmax(zc-t,0) - pmax(-zc-t,0)));
}

// [[Rcpp::export]]
arma::colvec Sc(arma::colvec z, double t){
  double normdelta = norm(z,2);
  arma::colvec a = zeros(z.size());
  if (1 - t/normdelta > 0){
    a=(1-t/normdelta)*z;
  }
  return a;
}

// [[Rcpp::export]]
arma::colvec f_scadc(double lamda, double kappa, arma::colvec zeta, double gamma){
  double normdelta = norm(zeta,2);
  arma::colvec a = zeros(zeta.size());
  if (normdelta <= (lamda+lamda/kappa)){
    a = Sc(zeta,lamda/kappa);
  }else if (normdelta>gamma*lamda){
    a = zeta;
  }else{
    a=Sc(zeta,gamma*lamda/((gamma-1)*kappa))/(1-1/((gamma-1)*kappa));
  }
  return a;
}

// [[Rcpp::export]]
arma::mat reshapev(const arma::colvec& v, int nrows, int ncols){
  arma::mat m1;
  m1.insert_cols(0, v);
  m1.reshape(nrows, ncols);
  return m1;
}

// [[Rcpp::export]]
List admmcpp(arma::colvec Ybc, arma::mat Zbc, arma::mat thec,  arma::mat Z_matrixc, arma::mat Ac, double lamda1, double lamda2,
             double kappa, double gamma, int iter_admm, double eps, arma::mat Z_invc){
  int n_m = Zbc.n_rows;
  int h = Zbc.n_cols;
  int p = n_m*(n_m-1)/2;

  arma::colvec the1c = vectorise(thec);
  arma::colvec eta1c = Ac*the1c;
  arma::mat Eta1c = reshapev(eta1c,h,p);
  arma::mat V1c = zeros(h,p);
  arma::colvec v1c = vectorise(V1c);
  int l = 0;
  double diff = 11;
  arma::colvec u1c = vectorise(thec);
  arma::colvec vebar1c = zeros(n_m*h);
  while (diff > eps){
    l = l + 1;
    the1c = Z_invc*(Z_matrixc.t()*Ybc+ kappa*Ac.t()*(eta1c-v1c/kappa) 
                      + kappa*(u1c-vebar1c/kappa));
    arma::colvec Xic = the1c + vebar1c/kappa;
    // u1c = as<arma::colvec>(STc(as<NumericVector>(wrap(Xic)),lamda2/kappa));
    u1c = STc(Xic, lamda2/kappa);
    vebar1c = vebar1c + kappa*(the1c-u1c);
    Eta1c = reshape(Ac*the1c,h,p);
    arma::mat Zetac = Eta1c + V1c/kappa;
    for(int j=0; j<p; j++) {
      Eta1c.cols(j,j) = f_scadc(lamda1,kappa, Zetac.cols(j,j),gamma);
    } 
    eta1c = vectorise(Eta1c);
    arma::mat Athetac = reshapev(Ac*the1c, h, p);
    V1c = V1c+kappa*(Athetac-Eta1c);
    v1c = vectorise(V1c);
    double d1 = norm(Athetac-Eta1c,"fro");
    double d2 = norm(the1c-u1c,2);
    diff = d1;
    if (diff < d2){
      diff = d2;
    }
    // Rprintf("%i %f \n", l,diff);
    if (l > iter_admm ){
      Rprintf("the max iteration is reaching \n");
      break;
    }
  }
  List res = List::create(Named("theta_b") = u1c, _("etab") = Eta1c,
                          _["Diff"] = diff, _["IT"] =l);
  return res;
}


